export interface Product {
    category: string;
    image: string;
    name: string;
    description: string;
    rating: number;
    link: string;
}

export const products = [
    {
        id: 1,
        category:'Accessories',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/h95/h0e/63961934823454.jpg?format=gallery-large',
        name: 'Зарядное устройство Apple 20W USB-C Power Adapter белый',
        description: 'тип: сетевая зарядка\n' +
            'количество подключаемых устройств: 1\n' +
            'быстрая зарядка: Да\n' +
            'разъем подключения: USB Type-C',
        rating: 4.5,
        link: "https://kaspi.kz/shop/p/apple-20w-usb-c-power-adapter-belyi-100984093/?c=750000000"
    },
    {
        id: 2,
        category:'Phones',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/h32/h70/84378448199710.jpg?format=gallery-large',
        name: 'Смартфон Apple iPhone 13 128Gb Midnight черный',
        description: "технология NFC: Да\nцвет: черный\nтип экрана: OLED, Super Retina XDR\nдиагональ: 6.1 дюйм\nразмер оперативной памяти: 4 ГБ\nпроцессор: 6-ядерный Apple A15 Bionic\nобъем встроенной памяти: 128.0 ГБ\nемкость аккумулятора: 3095.0 мАч",
        rating: 5,
        link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
    },
    {
        id: 3,
        category:'Phones',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/h32/h70/84378448199710.jpg?format=gallery-large',
        name: 'Смартфон Apple iPhone 14 128Gb черный',
        description: "технология NFC: Да\n" +
            "цвет: черный\n" +
            "тип экрана: OLED, Super Retina XDR display\n" +
            "диагональ: 6.1 дюйм\n" +
            "размер оперативной памяти: 6 ГБ\n" +
            "процессор: 6-ядерный Apple A15 Bionic\n" +
            "объем встроенной памяти: 128.0 ГБ\n" +
            "емкость аккумулятора: 3279.0 мАч",
        rating: 4.5,
        link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
    },
    {
        id: 4,
        category:'Phones',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/h02/ha0/79846423199774.jpg?format=gallery-large',
        name: 'Смартфон Xiaomi Redmi Note 12 Pro 4G 8 ГБ/256 ГБ серый',
        description: "технология NFC: Да\n" +
            "цвет: серый\n" +
            "тип экрана: AMOLED, сенсорный, мультитач\n" +
            "диагональ: 6.67 дюйм\n" +
            "размер оперативной памяти: 8 ГБ\n" +
            "процессор: 8-ядерный Qualcomm Snapdragon 732G\n" +
            "объем встроенной памяти: 256.0 ГБ\n" +
            "емкость аккумулятора: 5000.0 мАч",
        rating: 4.5,
        link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
    },
    {
        id: 5,
        category:'Watches',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/hf5/hed/64420698554398.jpg?format=gallery-large',
        name: 'Смарт-часы COLMI P28 Plus золотистый-бежевый',
        description: "поддержка платформ: Android, ,iOS\n" +
            "цвет корпуса: золотистый\n" +
            "форма корпуса: прямоугольная\n" +
            "интерфейсы: Bluetooth\n" +
            "время работы: 3-7 дней",
        rating: 5,
        link: "https://kaspi.kz/shop/p/colmi-p28-plus-zolotistyi-bezhevyi-106175099/?c=750000000"
    },
    {
        id: 6,
        category:'Accessories',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/h62/h38/67432964784158.jpg?format=gallery-large',
        name: 'Чехол OEM для Apple iPhone 13 прозрачный',
        description: "тип: накладка\n" +
            "совместимый бренд: Apple\n" +
            "материал: силикон, ,пластик\n" +
            "совместимые модели: iPhone 13",
        rating: 5,
        link: "https://kaspi.kz/shop/p/oem-dlja-apple-iphone-13-prozrachnyi-108272841/?c=750000000"
    },
    {
        id: 7,
        category:'Accessories',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/hbd/h2f/63829403140126.jpg?format=gallery-large',
        name: 'Кабель Apple USB Type-C - Lightning 1 м',
        description: "разъемы: Apple Lightning (M), ,USB TypeC (M)\n" +
            "тип: кабель\n" +
            "длина: 1.0 м",
        rating: 4,
        link: "https://kaspi.kz/shop/p/kabel-apple-usb-type-c---lightning-1-m-40500508/?c=750000000"
    },
    {
        id: 8,
        category:'Watches',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/hb0/h7e/63639753555998.jpg?format=gallery-large',
        name: 'Смарт-часы COLMI P28 Plus черный',
        description: "поддержка платформ: Android, ,iOS\n" +
            "цвет корпуса: черный\n" +
            "форма корпуса: прямоугольная\n" +
            "интерфейсы: Bluetooth\n" +
            "время работы: 3-7 дней",
        rating: 4.5,
        link: "https://kaspi.kz/shop/p/colmi-p28-plus-chernyi-106096505/?c=750000000"
    },
    {
        id: 9,
        category:'Accessories',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/ha9/h3b/67897720340510.jpg?format=gallery-large',
        name: 'Стекло для Apple iPhone 11',
        description: "тип: стекло\n" +
            "совместимый бренд: Apple\n" +
            "совместимые модели: iPhone 11\n" +
            "назначение: дисплей\n" +
            "вид покрытия: противоударное",
        rating: 4.5,
        link: "https://kaspi.kz/shop/p/steklo-dlja-apple-iphone-11-108450817/?c=750000000"
    },
    {
        id: 10,
        category:'Accessories',
        image: 'https://resources.cdn-kaspi.kz/img/m/p/h2e/h29/64381795991582.jpg?format=gallery-large',
        name: 'Держатель для телефона Ali17express 2291',
        description: "назначение: для смартфона\n" +
            "тип: держатель\n" +
            "место крепления держателя: универсальное, ,настольное\n" +
            "способ крепления держателя: зажим",
        rating: 4.5,
        link: "https://kaspi.kz/shop/p/ali17express-2291-104227273/?c=750000000"
    },
  {
    id: 11,
    category:'Books',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h47/h4b/64225442988062.jpg?format=gallery-large',
    name: 'Книга Лондон Д.: Мартин Иден',
    description: "язык издания: русский\n" +
      "переплет: мягкий переплет\n" +
      "жанр: всемирная классика\n" +
      "автор: Джек Лондон",
    rating: 5,
    link: "https://kaspi.kz/shop/p/london-d-martin-iden-101137240/?c=750000000"
  },
  {
    id: 12,
    category:'Books',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h40/h09/82716044722206.jpg?format=gallery-large',
    name: 'Книга Александр Дюма: Граф Монте-Кристо',
    description: "возраст: 16+\n" +
      "язык издания: казахский\n" +
      "переплет: твердый переплет\n" +
      "жанр: всемирная классика\n"+
      "автор: Александр Дюма",
    rating: 5,
    link: "https://kaspi.kz/shop/p/aleksandr-djuma-graf-monte-kristo-112438321/?c=750000000"
  },
  {
    id: 13,
    category:'Books',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h00/h64/64096830750750.jpg?format=gallery-large',
    name: 'Книга Уайльд О.: Портрет Дориана Грея',
    description: "язык издания: русский\n" +
      "переплет: мягкий переплет\n" +
      "жанр: всемирная классика\n"+
      "автор: Оскар Уайльд",
    rating: 5,
    link: "https://kaspi.kz/shop/p/uail-d-o-portret-doriana-greja-100996924/?c=750000000"
  },
  {
    id: 14,
    category:'Books',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h72/h3f/64684926697502.jpg?format=gallery-large',
    name: 'Книга Хейр С.: Чисто английское убийство',
    description: "язык издания: русский\n" +
      "переплет: мягкий переплет\n" +
      "жанр: остросюжетная литература\n"+
      "автор: Сирил Хейр",
    rating: 5,
    link: "https://kaspi.kz/shop/p/heir-s-chisto-angliiskoe-ubiistvo-103444754/?c=750000000"
  },
  {
    id: 15,
    category:'Books',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h94/h8b/64433739497502.jpg?format=gallery-large',
    name: 'Книга Симонов К.М.: Живые и мертвые',
    description: "язык издания: русский\n" +
      "переплет: твердый переплет\n" +
      "жанр: современная мировая проза\n"+
      "автор: Константин Симонов",
    rating: 5,
    link: "https://kaspi.kz/shop/p/simonov-k-m-zhivye-i-mertvye-105919459/?c=750000000"
  },
  {
    id: 16,
    category:'Phones',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h5e/h53/69635680763934.jpg?format=gallery-large',
    name: 'Смартфон Samsung Galaxy S23 Ultra 12 ГБ/256 ГБ черный',
    description: "технология NFC: Да\n" +
      "цвет: черный\n" +
      "тип экрана: Dynamic AMOLED 2X, HDR10+, Corning Gorilla Glass Victus+\n" +
      "диагональ: 6.8 дюйм\n"+
      "размер оперативной памяти: 12 ГБ\n" +
      "процессор: Qualcomm Snapdragon 8 Gen2\n" +
      "объем встроенной памяти: 256.0 ГБ\n" +
      "емкость аккумулятора: 5000.0 мАч",
    rating: 5,
    link: "https://kaspi.kz/shop/p/samsung-galaxy-s23-ultra-12-gb-256-gb-chernyi-109174566/?c=750000000"
  },
  {
    id: 17,
    category:'Phones',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hfc/h07/84326675808286.jpg?format=gallery-large',
    name: 'Смартфон Google Pixel 8 8 ГБ/128 ГБ серый',
    description: "технология NFC: Да\n" +
      "технология NFC: Да\n" +
      "цвет: серый\n" +
      "тип экрана: OLED, Gorilla Glass Victus\n" +
      "диагональ: 6.2 дюйм\n" +
      "размер оперативной памяти: 8 ГБ\n" +
      "процессор: 8-ядерный Google Tensor G3\n" +
      "объем встроенной памяти: 128.0 ГБ\n" +
      "емкость аккумулятора: 4575.0 мАч",
    rating: 5,
    link: "https://kaspi.kz/shop/p/google-pixel-8-8-gb-128-gb-seryi-114016975/?c=750000000"
  },
  {
    id: 18,
    category:'Watches',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h88/h5e/84373305294878.jpg?format=gallery-large',
    name: 'Смарт-часы Apple Watch SE 2 Gen (2023) GPS M/L 44 мм черно-синий',
    description: "поддержка платформ: iOS\n" +
      "материал корпуса: алюминий\n" +
      "цвет корпуса: черно-синий\n" +
      "форма корпуса: прямоугольная\n" +
      "интерфейсы: Bluetooth, ,Wi-Fi\n" +
      "технология экрана: OLED",
    rating: 5,
    link: "https://kaspi.kz/shop/p/apple-watch-se-2-gen-2023-gps-m-l-44-mm-cherno-sinii-114111998/?c=750000000"
  },
  {
    id: 19,
    category:'Watches',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h63/h88/64414071029790.jpg?format=gallery-large',
    name: 'Смарт-часы Samsung Galaxy Watch 5 Pro 45 мм серый',
    description: "поддержка платформ: Android\n" +
      "материал корпуса: титан\n" +
      "цвет корпуса: серый\n" +
      "форма корпуса: круглая\n" +
      "интерфейсы: Bluetooth, ,Wi-Fi\n" +
      "технология экрана: Super AMOLED\n" +
      "объем оперативной памяти: 1.5 Гб\n" +
      "объем встроенной памяти: 16 Гб\n" +
      "время работы: 40 часов",
    rating: 5,
    link: "https://kaspi.kz/shop/p/samsung-galaxy-watch-5-pro-45-mm-seryi-106174847/?c=750000000"
  },
  {
    id: 20,
    category:'Watches',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hc5/h2f/82181698158622.jpg?format=gallery-large',
    name: 'Часы Механические 15757390_776245 металлический сплав',
    description: "способ отображения времени: цифровой (электронный)\n" +
      "тип: механические\n" +
      "материал корпуса: металлический сплав\n" +
      "цвет: серебристый\n" +
      "для кого: для мужчин",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/mehanicheskie-15757390-776245-metallicheskii-splav-112049937/?c=750000000"
  },
  {
    id: 1,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h95/h0e/63961934823454.jpg?format=gallery-large',
    name: 'Зарядное устройство Apple 20W USB-C Power Adapter белый',
    description: 'тип: сетевая зарядка\n' +
      'количество подключаемых устройств: 1\n' +
      'быстрая зарядка: Да\n' +
      'разъем подключения: USB Type-C',
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/apple-20w-usb-c-power-adapter-belyi-100984093/?c=750000000"
  },
  {
    id: 2,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h32/h70/84378448199710.jpg?format=gallery-large',
    name: 'Смартфон Apple iPhone 13 128Gb Midnight черный',
    description: "технология NFC: Да\nцвет: черный\nтип экрана: OLED, Super Retina XDR\nдиагональ: 6.1 дюйм\nразмер оперативной памяти: 4 ГБ\nпроцессор: 6-ядерный Apple A15 Bionic\nобъем встроенной памяти: 128.0 ГБ\nемкость аккумулятора: 3095.0 мАч",
    rating: 5,
    link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
  },
  {
    id: 3,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h32/h70/84378448199710.jpg?format=gallery-large',
    name: 'Смартфон Apple iPhone 14 128Gb черный',
    description: "технология NFC: Да\n" +
      "цвет: черный\n" +
      "тип экрана: OLED, Super Retina XDR display\n" +
      "диагональ: 6.1 дюйм\n" +
      "размер оперативной памяти: 6 ГБ\n" +
      "процессор: 6-ядерный Apple A15 Bionic\n" +
      "объем встроенной памяти: 128.0 ГБ\n" +
      "емкость аккумулятора: 3279.0 мАч",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
  },
  {
    id: 4,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h02/ha0/79846423199774.jpg?format=gallery-large',
    name: 'Смартфон Xiaomi Redmi Note 12 Pro 4G 8 ГБ/256 ГБ серый',
    description: "технология NFC: Да\n" +
      "цвет: серый\n" +
      "тип экрана: AMOLED, сенсорный, мультитач\n" +
      "диагональ: 6.67 дюйм\n" +
      "размер оперативной памяти: 8 ГБ\n" +
      "процессор: 8-ядерный Qualcomm Snapdragon 732G\n" +
      "объем встроенной памяти: 256.0 ГБ\n" +
      "емкость аккумулятора: 5000.0 мАч",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
  },
  {
    id: 5,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hf5/hed/64420698554398.jpg?format=gallery-large',
    name: 'Смарт-часы COLMI P28 Plus золотистый-бежевый',
    description: "поддержка платформ: Android, ,iOS\n" +
      "цвет корпуса: золотистый\n" +
      "форма корпуса: прямоугольная\n" +
      "интерфейсы: Bluetooth\n" +
      "время работы: 3-7 дней",
    rating: 5,
    link: "https://kaspi.kz/shop/p/colmi-p28-plus-zolotistyi-bezhevyi-106175099/?c=750000000"
  },
  {
    id: 6,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h62/h38/67432964784158.jpg?format=gallery-large',
    name: 'Чехол OEM для Apple iPhone 13 прозрачный',
    description: "тип: накладка\n" +
      "совместимый бренд: Apple\n" +
      "материал: силикон, ,пластик\n" +
      "совместимые модели: iPhone 13",
    rating: 5,
    link: "https://kaspi.kz/shop/p/oem-dlja-apple-iphone-13-prozrachnyi-108272841/?c=750000000"
  },
  {
    id: 7,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hbd/h2f/63829403140126.jpg?format=gallery-large',
    name: 'Кабель Apple USB Type-C - Lightning 1 м',
    description: "разъемы: Apple Lightning (M), ,USB TypeC (M)\n" +
      "тип: кабель\n" +
      "длина: 1.0 м",
    rating: 4,
    link: "https://kaspi.kz/shop/p/kabel-apple-usb-type-c---lightning-1-m-40500508/?c=750000000"
  },
  {
    id: 8,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hb0/h7e/63639753555998.jpg?format=gallery-large',
    name: 'Смарт-часы COLMI P28 Plus черный',
    description: "поддержка платформ: Android, ,iOS\n" +
      "цвет корпуса: черный\n" +
      "форма корпуса: прямоугольная\n" +
      "интерфейсы: Bluetooth\n" +
      "время работы: 3-7 дней",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/colmi-p28-plus-chernyi-106096505/?c=750000000"
  },
  {
    id: 9,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/ha9/h3b/67897720340510.jpg?format=gallery-large',
    name: 'Стекло для Apple iPhone 11',
    description: "тип: стекло\n" +
      "совместимый бренд: Apple\n" +
      "совместимые модели: iPhone 11\n" +
      "назначение: дисплей\n" +
      "вид покрытия: противоударное",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/steklo-dlja-apple-iphone-11-108450817/?c=750000000"
  },
  {
    id: 10,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h2e/h29/64381795991582.jpg?format=gallery-large',
    name: 'Держатель для телефона Ali17express 2291',
    description: "назначение: для смартфона\n" +
      "тип: держатель\n" +
      "место крепления держателя: универсальное, ,настольное\n" +
      "способ крепления держателя: зажим",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/ali17express-2291-104227273/?c=750000000"
  },
  {
    id: 11,
    category:'ALl',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h47/h4b/64225442988062.jpg?format=gallery-large',
    name: 'Книга Лондон Д.: Мартин Иден',
    description: "язык издания: русский\n" +
      "переплет: мягкий переплет\n" +
      "жанр: всемирная классика\n" +
      "автор: Джек Лондон",
    rating: 5,
    link: "https://kaspi.kz/shop/p/london-d-martin-iden-101137240/?c=750000000"
  },
  {
    id: 12,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h40/h09/82716044722206.jpg?format=gallery-large',
    name: 'Книга Александр Дюма: Граф Монте-Кристо',
    description: "возраст: 16+\n" +
      "язык издания: казахский\n" +
      "переплет: твердый переплет\n" +
      "жанр: всемирная классика\n"+
      "автор: Александр Дюма",
    rating: 5,
    link: "https://kaspi.kz/shop/p/aleksandr-djuma-graf-monte-kristo-112438321/?c=750000000"
  },
  {
    id: 13,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h00/h64/64096830750750.jpg?format=gallery-large',
    name: 'Книга Уайльд О.: Портрет Дориана Грея',
    description: "язык издания: русский\n" +
      "переплет: мягкий переплет\n" +
      "жанр: всемирная классика\n"+
      "автор: Оскар Уайльд",
    rating: 5,
    link: "https://kaspi.kz/shop/p/uail-d-o-portret-doriana-greja-100996924/?c=750000000"
  },
  {
    id: 14,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h72/h3f/64684926697502.jpg?format=gallery-large',
    name: 'Книга Хейр С.: Чисто английское убийство',
    description: "язык издания: русский\n" +
      "переплет: мягкий переплет\n" +
      "жанр: остросюжетная литература\n"+
      "автор: Сирил Хейр",
    rating: 5,
    link: "https://kaspi.kz/shop/p/heir-s-chisto-angliiskoe-ubiistvo-103444754/?c=750000000"
  },
  {
    id: 15,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h94/h8b/64433739497502.jpg?format=gallery-large',
    name: 'Книга Симонов К.М.: Живые и мертвые',
    description: "язык издания: русский\n" +
      "переплет: твердый переплет\n" +
      "жанр: современная мировая проза\n"+
      "автор: Константин Симонов",
    rating: 5,
    link: "https://kaspi.kz/shop/p/simonov-k-m-zhivye-i-mertvye-105919459/?c=750000000"
  },
  {
    id: 16,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h5e/h53/69635680763934.jpg?format=gallery-large',
    name: 'Смартфон Samsung Galaxy S23 Ultra 12 ГБ/256 ГБ черный',
    description: "технология NFC: Да\n" +
      "цвет: черный\n" +
      "тип экрана: Dynamic AMOLED 2X, HDR10+, Corning Gorilla Glass Victus+\n" +
      "диагональ: 6.8 дюйм\n"+
      "размер оперативной памяти: 12 ГБ\n" +
      "процессор: Qualcomm Snapdragon 8 Gen2\n" +
      "объем встроенной памяти: 256.0 ГБ\n" +
      "емкость аккумулятора: 5000.0 мАч",
    rating: 5,
    link: "https://kaspi.kz/shop/p/samsung-galaxy-s23-ultra-12-gb-256-gb-chernyi-109174566/?c=750000000"
  },
  {
    id: 17,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hfc/h07/84326675808286.jpg?format=gallery-large',
    name: 'Смартфон Google Pixel 8 8 ГБ/128 ГБ серый',
    description: "технология NFC: Да\n" +
      "технология NFC: Да\n" +
      "цвет: серый\n" +
      "тип экрана: OLED, Gorilla Glass Victus\n" +
      "диагональ: 6.2 дюйм\n" +
      "размер оперативной памяти: 8 ГБ\n" +
      "процессор: 8-ядерный Google Tensor G3\n" +
      "объем встроенной памяти: 128.0 ГБ\n" +
      "емкость аккумулятора: 4575.0 мАч",
    rating: 5,
    link: "https://kaspi.kz/shop/p/google-pixel-8-8-gb-128-gb-seryi-114016975/?c=750000000"
  },
  {
    id: 18,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h88/h5e/84373305294878.jpg?format=gallery-large',
    name: 'Смарт-часы Apple Watch SE 2 Gen (2023) GPS M/L 44 мм черно-синий',
    description: "поддержка платформ: iOS\n" +
      "материал корпуса: алюминий\n" +
      "цвет корпуса: черно-синий\n" +
      "форма корпуса: прямоугольная\n" +
      "интерфейсы: Bluetooth, ,Wi-Fi\n" +
      "технология экрана: OLED",
    rating: 5,
    link: "https://kaspi.kz/shop/p/apple-watch-se-2-gen-2023-gps-m-l-44-mm-cherno-sinii-114111998/?c=750000000"
  },
  {
    id: 19,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/h63/h88/64414071029790.jpg?format=gallery-large',
    name: 'Смарт-часы Samsung Galaxy Watch 5 Pro 45 мм серый',
    description: "поддержка платформ: Android\n" +
      "материал корпуса: титан\n" +
      "цвет корпуса: серый\n" +
      "форма корпуса: круглая\n" +
      "интерфейсы: Bluetooth, ,Wi-Fi\n" +
      "технология экрана: Super AMOLED\n" +
      "объем оперативной памяти: 1.5 Гб\n" +
      "объем встроенной памяти: 16 Гб\n" +
      "время работы: 40 часов",
    rating: 5,
    link: "https://kaspi.kz/shop/p/samsung-galaxy-watch-5-pro-45-mm-seryi-106174847/?c=750000000"
  },
  {
    id: 20,
    category:'All',
    image: 'https://resources.cdn-kaspi.kz/img/m/p/hc5/h2f/82181698158622.jpg?format=gallery-large',
    name: 'Часы Механические 15757390_776245 металлический сплав',
    description: "способ отображения времени: цифровой (электронный)\n" +
      "тип: механические\n" +
      "материал корпуса: металлический сплав\n" +
      "цвет: серебристый\n" +
      "для кого: для мужчин",
    rating: 4.5,
    link: "https://kaspi.kz/shop/p/mehanicheskie-15757390-776245-metallicheskii-splav-112049937/?c=750000000"
  },
];













// export const watches = [
//   {
//     id: 1,
//     category:'Watches',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h88/h5e/84373305294878.jpg?format=gallery-large',
//     name: 'Смарт-часы Apple Watch SE 2 Gen (2023) GPS M/L 44 мм черно-синий',
//     description: "поддержка платформ: iOS\n" +
//       "материал корпуса: алюминий\n" +
//       "цвет корпуса: черно-синий\n" +
//       "форма корпуса: прямоугольная\n" +
//       "интерфейсы: Bluetooth, ,Wi-Fi\n" +
//       "технология экрана: OLED",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/apple-watch-se-2-gen-2023-gps-m-l-44-mm-cherno-sinii-114111998/?c=750000000"
//   },
//   {
//     id: 2,
//     category:'Watches',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h63/h88/64414071029790.jpg?format=gallery-large',
//     name: 'Смарт-часы Samsung Galaxy Watch 5 Pro 45 мм серый',
//     description: "поддержка платформ: Android\n" +
//       "материал корпуса: титан\n" +
//       "цвет корпуса: серый\n" +
//       "форма корпуса: круглая\n" +
//       "интерфейсы: Bluetooth, ,Wi-Fi\n" +
//       "технология экрана: Super AMOLED\n" +
//       "объем оперативной памяти: 1.5 Гб\n" +
//       "объем встроенной памяти: 16 Гб\n" +
//       "время работы: 40 часов",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/samsung-galaxy-watch-5-pro-45-mm-seryi-106174847/?c=750000000"
//   },
//   {
//     id: 3,
//     category:'Watches',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/hc5/h2f/82181698158622.jpg?format=gallery-large',
//     name: 'Часы Механические 15757390_776245 металлический сплав',
//     description: "способ отображения времени: цифровой (электронный)\n" +
//       "тип: механические\n" +
//       "материал корпуса: металлический сплав\n" +
//       "цвет: серебристый\n" +
//       "для кого: для мужчин",
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/mehanicheskie-15757390-776245-metallicheskii-splav-112049937/?c=750000000"
//   },
//   {
//     id: 4,
//     category:'Watches',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/hb0/h7e/63639753555998.jpg?format=gallery-large',
//     name: 'Смарт-часы COLMI P28 Plus черный',
//     description: "поддержка платформ: Android, ,iOS\n" +
//       "цвет корпуса: черный\n" +
//       "форма корпуса: прямоугольная\n" +
//       "интерфейсы: Bluetooth\n" +
//       "время работы: 3-7 дней",
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/colmi-p28-plus-chernyi-106096505/?c=750000000"
//   },
//   {
//     id: 5,
//     category:'Watches',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/hf5/hed/64420698554398.jpg?format=gallery-large',
//     name: 'Смарт-часы COLMI P28 Plus золотистый-бежевый',
//     description: "поддержка платформ: Android, ,iOS\n" +
//       "цвет корпуса: золотистый\n" +
//       "форма корпуса: прямоугольная\n" +
//       "интерфейсы: Bluetooth\n" +
//       "время работы: 3-7 дней",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/colmi-p28-plus-zolotistyi-bezhevyi-106175099/?c=750000000"
//   },
// ];
//
// export const books=[
//   {
//     id: 1,
//     category:'Books',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h47/h4b/64225442988062.jpg?format=gallery-large',
//     name: 'Книга Лондон Д.: Мартин Иден',
//     description: "язык издания: русский\n" +
//       "переплет: мягкий переплет\n" +
//       "жанр: всемирная классика\n" +
//       "автор: Джек Лондон",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/london-d-martin-iden-101137240/?c=750000000"
//   },
//   {
//     id: 2,
//     category:'Books',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h40/h09/82716044722206.jpg?format=gallery-large',
//     name: 'Книга Александр Дюма: Граф Монте-Кристо',
//     description: "возраст: 16+\n" +
//       "язык издания: казахский\n" +
//       "переплет: твердый переплет\n" +
//       "жанр: всемирная классика\n"+
//       "автор: Александр Дюма",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/aleksandr-djuma-graf-monte-kristo-112438321/?c=750000000"
//   },
//   {
//     id: 3,
//     category:'Books',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h00/h64/64096830750750.jpg?format=gallery-large',
//     name: 'Книга Уайльд О.: Портрет Дориана Грея',
//     description: "язык издания: русский\n" +
//       "переплет: мягкий переплет\n" +
//       "жанр: всемирная классика\n"+
//       "автор: Оскар Уайльд",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/uail-d-o-portret-doriana-greja-100996924/?c=750000000"
//   },
//   {
//     id: 4,
//     category:'Books',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h72/h3f/64684926697502.jpg?format=gallery-large',
//     name: 'Книга Хейр С.: Чисто английское убийство',
//     description: "язык издания: русский\n" +
//       "переплет: мягкий переплет\n" +
//       "жанр: остросюжетная литература\n"+
//       "автор: Сирил Хейр",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/heir-s-chisto-angliiskoe-ubiistvo-103444754/?c=750000000"
//   },
//   {
//     id: 5,
//     category:'Books',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h94/h8b/64433739497502.jpg?format=gallery-large',
//     name: 'Книга Симонов К.М.: Живые и мертвые',
//     description: "язык издания: русский\n" +
//       "переплет: твердый переплет\n" +
//       "жанр: современная мировая проза\n"+
//       "автор: Константин Симонов",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/simonov-k-m-zhivye-i-mertvye-105919459/?c=750000000"
//   },
// ];
//
// export const accessories = [
//   {
//     id: 1,
//     category:'Accessories',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h95/h0e/63961934823454.jpg?format=gallery-large',
//     name: 'Зарядное устройство Apple 20W USB-C Power Adapter белый',
//     description: 'тип: сетевая зарядка\n' +
//       'количество подключаемых устройств: 1\n' +
//       'быстрая зарядка: Да\n' +
//       'разъем подключения: USB Type-C',
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/apple-20w-usb-c-power-adapter-belyi-100984093/?c=750000000"
//   },
//   {
//     id: 2,
//     category:'Accessories',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h62/h38/67432964784158.jpg?format=gallery-large',
//     name: 'Чехол OEM для Apple iPhone 13 прозрачный',
//     description: "тип: накладка\n" +
//       "совместимый бренд: Apple\n" +
//       "материал: силикон, ,пластик\n" +
//       "совместимые модели: iPhone 13",
//     rating: 3,
//     link: "https://kaspi.kz/shop/p/oem-dlja-apple-iphone-13-prozrachnyi-108272841/?c=750000000"
//   },
//   {
//     id: 3,
//     category:'Accessories',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/hbd/h2f/63829403140126.jpg?format=gallery-large',
//     name: 'Кабель Apple USB Type-C - Lightning 1 м',
//     description: "разъемы: Apple Lightning (M), ,USB TypeC (M)\n" +
//       "тип: кабель\n" +
//       "длина: 1.0 м",
//     rating: 4,
//     link: "https://kaspi.kz/shop/p/kabel-apple-usb-type-c---lightning-1-m-40500508/?c=750000000"
//   },
//   {
//     id: 4,
//     category:'Accessories',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/ha9/h3b/67897720340510.jpg?format=gallery-large',
//     name: 'Стекло для Apple iPhone 11',
//     description: "тип: стекло\n" +
//       "совместимый бренд: Apple\n" +
//       "совместимые модели: iPhone 11\n" +
//       "назначение: дисплей\n" +
//       "вид покрытия: противоударное",
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/steklo-dlja-apple-iphone-11-108450817/?c=750000000"
//   },
//   {
//     id: 5,
//     category:'Accessories',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h2e/h29/64381795991582.jpg?format=gallery-large',
//     name: 'Держатель для телефона Ali17express 2291',
//     description: "назначение: для смартфона\n" +
//       "тип: держатель\n" +
//       "место крепления держателя: универсальное, ,настольное\n" +
//       "способ крепления держателя: зажим",
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/ali17express-2291-104227273/?c=750000000"
//   },
// ];
//
// export const phones = [
//   {
//     id: 1,
//     category:'Phones',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h32/h70/84378448199710.jpg?format=gallery-large',
//     name: 'Смартфон Apple iPhone 13 128Gb Midnight черный',
//     description: "технология NFC: Да\nцвет: черный\nтип экрана: OLED, Super Retina XDR\nдиагональ: 6.1 дюйм\nразмер оперативной памяти: 4 ГБ\nпроцессор: 6-ядерный Apple A15 Bionic\nобъем встроенной памяти: 128.0 ГБ\nемкость аккумулятора: 3095.0 мАч",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
//   },
//   {
//     id: 2,
//     category:'Phones',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h32/h70/84378448199710.jpg?format=gallery-large',
//     name: 'Смартфон Apple iPhone 14 128Gb черный',
//     description: "технология NFC: Да\n" +
//       "цвет: черный\n" +
//       "тип экрана: OLED, Super Retina XDR display\n" +
//       "диагональ: 6.1 дюйм\n" +
//       "размер оперативной памяти: 6 ГБ\n" +
//       "процессор: 6-ядерный Apple A15 Bionic\n" +
//       "объем встроенной памяти: 128.0 ГБ\n" +
//       "емкость аккумулятора: 3279.0 мАч",
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
//   },
//   {
//     id: 3,
//     category:'Phones',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h02/ha0/79846423199774.jpg?format=gallery-large',
//     name: 'Смартфон Xiaomi Redmi Note 12 Pro 4G 8 ГБ/256 ГБ серый',
//     description: "технология NFC: Да\n" +
//       "цвет: серый\n" +
//       "тип экрана: AMOLED, сенсорный, мультитач\n" +
//       "диагональ: 6.67 дюйм\n" +
//       "размер оперативной памяти: 8 ГБ\n" +
//       "процессор: 8-ядерный Qualcomm Snapdragon 732G\n" +
//       "объем встроенной памяти: 256.0 ГБ\n" +
//       "емкость аккумулятора: 5000.0 мАч",
//     rating: 4.5,
//     link: "https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000"
//   },
//   {
//     id: 4,
//     category:'Phones',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/h5e/h53/69635680763934.jpg?format=gallery-large',
//     name: 'Смартфон Samsung Galaxy S23 Ultra 12 ГБ/256 ГБ черный',
//     description: "технология NFC: Да\n" +
//       "цвет: черный\n" +
//       "тип экрана: Dynamic AMOLED 2X, HDR10+, Corning Gorilla Glass Victus+\n" +
//       "диагональ: 6.8 дюйм\n"+
//       "размер оперативной памяти: 12 ГБ\n" +
//       "процессор: Qualcomm Snapdragon 8 Gen2\n" +
//       "объем встроенной памяти: 256.0 ГБ\n" +
//       "емкость аккумулятора: 5000.0 мАч",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/samsung-galaxy-s23-ultra-12-gb-256-gb-chernyi-109174566/?c=750000000"
//   },
//   {
//     id: 5,
//     category:'Phones',
//     image: 'https://resources.cdn-kaspi.kz/img/m/p/hfc/h07/84326675808286.jpg?format=gallery-large',
//     name: 'Смартфон Google Pixel 8 8 ГБ/128 ГБ серый',
//     description: "технология NFC: Да\n" +
//       "технология NFC: Да\n" +
//       "цвет: серый\n" +
//       "тип экрана: OLED, Gorilla Glass Victus\n" +
//       "диагональ: 6.2 дюйм\n" +
//       "размер оперативной памяти: 8 ГБ\n" +
//       "процессор: 8-ядерный Google Tensor G3\n" +
//       "объем встроенной памяти: 128.0 ГБ\n" +
//       "емкость аккумулятора: 4575.0 мАч",
//     rating: 5,
//     link: "https://kaspi.kz/shop/p/google-pixel-8-8-gb-128-gb-seryi-114016975/?c=750000000"
//   },
// ];
