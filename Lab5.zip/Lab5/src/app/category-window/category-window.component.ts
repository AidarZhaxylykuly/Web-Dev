import { Component } from '@angular/core';
import {NgForOf, NgIf} from "@angular/common";
// import {ProductListComponent} from '../product-list/product-list.component';

@Component({
  selector: 'app-category-window',
  standalone: true,
  imports: [
    NgForOf,
    NgIf,
  ],
  templateUrl: './category-window.component.html',
  styleUrl: './category-window.component.css'
})
export class CategoryWindowComponent {
  flag: boolean = false;
  chosenCategory: string = "";
  openLsofCategories(){
    if(!this.flag){
      this.flag=true;
    }
    else {
      this.flag = false;
    }
  }

  changeCategory(newCategory: string){
    this.chosenCategory= newCategory;
  }
}
