import {Component, ViewChild} from '@angular/core';

import {products} from '../products';

import { CategoryWindowComponent } from '../category-window/category-window.component';
@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
    products = [...products];
    @ViewChild(CategoryWindowComponent) chosenCategory1: CategoryWindowComponent | undefined;
    share(text: string) {
        navigator.clipboard.writeText(text).then(function () {
            console.log('Async: Copying to clipboard was successful!');
            window.open('https://web.telegram.org/k/', '_blank');
        }, function (err) {
            console.error('Async: Could not copy text: ', err);
        });

    }
}
